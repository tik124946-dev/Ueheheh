#include "util.hpp"
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <sys/stat.h>
#include <dirent.h>
#include <errno.h>
#include <ctype.h>

#ifdef __SWITCH__
#include <switch.h>
uint64_t now_ms() { return armTicksToNs(armGetSystemTick()) / 1000000ull; }
#else
uint64_t now_ms() {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)ts.tv_sec * 1000ull + ts.tv_nsec / 1000000ull;
}
#endif

bool mkdirs(const std::string& path) {
    std::string cur;
    size_t i = 0;
    // пропускаем префикс вида "sdmc:/"
    size_t colon = path.find(":/");
    if (colon != std::string::npos) { cur = path.substr(0, colon + 2); i = colon + 2; }
    else if (!path.empty() && path[0] == '/') { cur = "/"; i = 1; }
    while (i <= path.size()) {
        size_t j = path.find('/', i);
        if (j == std::string::npos) j = path.size();
        std::string part = path.substr(i, j - i);
        if (!part.empty()) {
            cur += part;
            if (mkdir(cur.c_str(), 0777) != 0 && errno != EEXIST) {
                struct stat st;
                if (stat(cur.c_str(), &st) != 0 || !S_ISDIR(st.st_mode)) return false;
            }
            cur += "/";
        }
        i = j + 1;
    }
    return true;
}

bool read_file(const std::string& path, std::vector<uint8_t>& out, size_t max) {
    FILE* f = fopen(path.c_str(), "rb");
    if (!f) return false;
    out.clear();
    uint8_t buf[8192];
    size_t n;
    while ((n = fread(buf, 1, sizeof buf, f)) > 0) {
        out.insert(out.end(), buf, buf + n);
        if (out.size() > max) { fclose(f); return false; }
    }
    fclose(f);
    return true;
}

bool write_file(const std::string& path, const std::string& data) {
    std::string tmp = path + ".tmp";
    FILE* f = fopen(tmp.c_str(), "wb");
    if (!f) return false;
    bool ok = fwrite(data.data(), 1, data.size(), f) == data.size();
    ok = (fclose(f) == 0) && ok;
    if (!ok) { remove(tmp.c_str()); return false; }
    remove(path.c_str());
    return rename(tmp.c_str(), path.c_str()) == 0;
}

bool list_dir(const std::string& path, std::vector<std::string>& names) {
    names.clear();
    DIR* d = opendir(path.c_str());
    if (!d) return false;
    while (struct dirent* e = readdir(d)) {
        if (!strcmp(e->d_name, ".") || !strcmp(e->d_name, "..")) continue;
        names.push_back(e->d_name);
    }
    closedir(d);
    return true;
}

bool file_exists(const std::string& path) {
    struct stat st;
    return stat(path.c_str(), &st) == 0;
}

static std::string fmt(const char* f, double v, const char* unit) {
    char b[64];
    snprintf(b, sizeof b, f, v);
    return std::string(b) + " " + unit;
}

std::string human_size(double b) {
    if (b < 0) b = 0;
    if (b < 1024) return fmt("%.0f", b, "Б");
    if (b < 1024.0 * 1024) return fmt("%.1f", b / 1024, "КБ");
    if (b < 1024.0 * 1024 * 1024) return fmt("%.1f", b / 1048576.0, "МБ");
    return fmt("%.2f", b / 1073741824.0, "ГБ");
}

std::string human_speed(double bps) {
    if (bps < 1024) return fmt("%.0f", bps, "Б/с");
    if (bps < 1024.0 * 1024) return fmt("%.0f", bps / 1024, "КБ/с");
    return fmt("%.2f", bps / 1048576.0, "МБ/с");
}

std::string human_time(int64_t s) {
    char b[48];
    if (s < 0) return "—";
    if (s < 60) snprintf(b, sizeof b, "%d с", (int)s);
    else if (s < 3600) snprintf(b, sizeof b, "%d мин %02d с", (int)(s / 60), (int)(s % 60));
    else if (s < 100 * 3600) snprintf(b, sizeof b, "%d ч %02d мин", (int)(s / 3600), (int)(s % 3600 / 60));
    else return "—";
    return b;
}

std::string to_hex(const uint8_t* p, size_t n) {
    static const char* d = "0123456789abcdef";
    std::string s;
    for (size_t i = 0; i < n; i++) { s += d[p[i] >> 4]; s += d[p[i] & 15]; }
    return s;
}

bool from_hex(const std::string& s, uint8_t* out, size_t n) {
    if (s.size() != n * 2) return false;
    for (size_t i = 0; i < n; i++) {
        int v = 0;
        for (int k = 0; k < 2; k++) {
            char c = s[i * 2 + k];
            int x = (c >= '0' && c <= '9') ? c - '0' : (c >= 'a' && c <= 'f') ? c - 'a' + 10 : (c >= 'A' && c <= 'F') ? c - 'A' + 10 : -1;
            if (x < 0) return false;
            v = v * 16 + x;
        }
        out[i] = (uint8_t)v;
    }
    return true;
}

std::string lower(std::string s) {
    for (auto& c : s) c = (char)tolower((unsigned char)c);
    return s;
}

bool ends_with_ci(const std::string& s, const char* suf) {
    size_t n = strlen(suf);
    if (s.size() < n) return false;
    return lower(s.substr(s.size() - n)) == suf;
}
