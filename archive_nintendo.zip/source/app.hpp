#pragma once
#include <stdint.h>
#include <memory>
#include <string>
#include <vector>
#include "platform.hpp"
#include "gfx.hpp"
#include "library.hpp"
#include "meta.hpp"
#include "router.hpp"
#include "swarm.hpp"

enum Key : uint32_t {
    K_A = 1, K_B = 2, K_X = 4, K_Y = 8, K_L = 16, K_R = 32, K_ZL = 64, K_ZR = 128,
    K_UP = 256, K_DOWN = 512, K_LEFT = 1024, K_RIGHT = 2048, K_PLUS = 4096, K_MINUS = 8192,
    K_ANY = 1u << 30        // любая другая кнопка или касание — только будит экран
};

class App {
public:
    explicit App(Platform* pf);
    ~App();
    void init();
    // keys — кнопки, нажатые в этом кадре. false — пора выходить.
    bool frame(uint32_t keys, uint64_t now);
    bool screen_off() const { return screen_off_; }
    // Полная перерисовка экрана занимает десятки миллисекунд, и всё это время сеть не читается.
    // Поэтому во время загрузки обновляем экран реже (по нажатию кнопки — сразу).
    bool dirty(uint64_t now) const { return !screen_off_ && (dirty_ || now - last_draw_ >= (job_running() ? 500u : 200u)); }
    void draw(Gfx& g, uint64_t now);

    uint64_t stall_limit_ms = 5 * 60 * 1000;   // сколько ждать без данных до выключения экрана
    int tab() const { return tab_; }
    size_t jobs_count() const { return jobs_.size(); }
    bool job_running() const;
    std::string job_state_text() const;
    void select_tab(int t) { tab_ = t; sel_[t] = 0; dirty_ = true; }
    bool dialog_open() const { return dlg_; }

private:
    struct TorEntry { std::string path, fname, name, hash; uint64_t total = 0; size_t nfiles = 0, ntr = 0, nsupp = 0; bool ok = false; std::string err; };
    struct Job {
        enum St { QUEUED, RUNNING, PAUSED, DONE, ERROR } st = QUEUED;
        std::string tpath, hash, err, note;
        Meta meta;
        std::unique_ptr<Router> router;
        std::unique_ptr<Swarm> swarm;
        size_t files_done = 0;
        uint64_t cur_off = 0;      // записано байт текущего файла (для NSP — позиция в потоке установки)
        std::string inst;          // состояние установки NSP
        int mode = 0;              // 0 — автоустановка, 1 — положить в папку
    };

    Platform* pf_;
    Library lib_;
    std::vector<TorEntry> tors_;
    std::vector<std::unique_ptr<Job>> jobs_;
    Meta preview_; int preview_idx_ = -1;
    int tab_ = 2;
    int sel_[3] = {0, 0, 0};
    int storage_ = 0;
    bool dlg_ = false;                 // окно «автоустановка или в папку»
    int dlg_sel_ = 0, last_mode_ = 0;
    TorEntry dlg_t_;
    bool screen_off_ = false, dirty_ = true, awake_ = false;
    uint64_t last_draw_ = 0, last_space_ = 0, toast_until_ = 0, confirm_until_ = 0;
    std::string toast_, confirm_key_;
    int64_t sd_free_ = -1, sd_total_ = -1;
    uint64_t t_stall_start_ = 0;
    bool exit_ = false;

    std::string tdir() const { return pf_->root() + "archive_nintendo/torrents"; }
    void scan_torrents();
    void toast(const std::string& s, uint64_t now, uint64_t ms = 4000) { toast_ = s; toast_until_ = now + ms; dirty_ = true; }
    bool confirm(const std::string& key, uint64_t now);
    Job* running() const;
    Job* find_job(const std::string& hash) const;
    void request_add(const TorEntry& t, uint64_t now);        // проверки и окно выбора
    void add_job(const TorEntry& t, int mode, uint64_t now);
    void dialog_keys(uint32_t keys, uint64_t now);
    void draw_dialog(Gfx& g);
    void start_job(Job& j, uint64_t now);
    void capture(Job& j);                 // запомнить, докуда дошли (для продолжения)
    void suspend_job(Job& j);             // остановка с сохранением
    void cancel_job(Job& j);              // остановка с откатом
    uint64_t last_save_ = 0;
    void finish_job(Job& j, uint64_t now);
    void queue_next(uint64_t now);
    void save_job(Job& j, int status);
    void update_awake();
    void on_a(uint64_t now);
    void on_x(uint64_t now);
    void handle_keys(uint32_t keys, uint64_t now);
    int list_len() const;
    std::vector<Job*> dl_jobs() const;
    std::vector<LibEntry*> done_entries();
    // отрисовка
    void draw_top(Gfx& g);
    void draw_side(Gfx& g);
    void draw_torrents(Gfx& g, uint64_t now);
    void draw_downloads(Gfx& g, uint64_t now);
    void draw_installed(Gfx& g);
    void draw_bottom(Gfx& g, uint64_t now);
    void draw_card(Gfx& g, Job& j, int x, int y, int w, uint64_t now);
    bool space_check(const Meta& m, size_t from_file, uint64_t done_in_first, bool inst, std::string& err);
};
