#pragma once
#include <stdint.h>
#include <string.h>
#include <string>
#include <vector>
#include <algorithm>

// Потоковый разбор PFS0 (контейнер NSP). Данные подаются порциями, файлы отдаются по мере поступления.
struct PfsHandler {
    virtual ~PfsHandler() {}
    // entry_off — смещение данных этого файла от начала NSP (нужно, чтобы просить пропуск)
    virtual bool pfs_begin(const std::string& name, uint64_t size, uint64_t entry_off) = 0;
    virtual bool pfs_data(const uint8_t* p, size_t n) = 0;
    virtual bool pfs_end() = 0;
    virtual bool pfs_gap(uint64_t n) { (void)n; return true; }   // часть текущего файла пропущена (поток прыгнул вперёд)
};

class PfsStream {
public:
    explicit PfsStream(PfsHandler* h) : h_(h) {}
    const std::string& error() const { return err_; }
    uint64_t pos() const { return pos_; }

    bool write(const uint8_t* p, size_t n) {
        if (!err_.empty()) return false;
        while (phase_ < 2 && n) {
            size_t want = need() - head_.size();
            size_t k = std::min(want, n);
            head_.insert(head_.end(), p, p + k);
            p += k; n -= k; pos_ += k;
            if (head_.size() == need()) {
                if (phase_ == 0) { if (!parse_header()) return false; phase_ = 1; if (need() == head_.size()) { if (!parse_entries()) return false; phase_ = 2; } }
                else { if (!parse_entries()) return false; phase_ = 2; }
            }
        }
        if (phase_ == 2) return stream(p, n);
        return true;
    }

    // Данные с абсолютным смещением в NSP. Если off впереди текущей позиции — это пропуск (seek) внутри
    // текущего файла или до начала следующего; перепрыгивать через границы файлов нельзя.
    bool write_at(uint64_t off, const uint8_t* p, size_t n) {
        if (!err_.empty()) return false;
        if (off < pos_) return fail("смещение назад в потоке NSP");
        if (off > pos_) {
            if (phase_ < 2) return fail("пропуск внутри заголовка NSP");
            uint64_t gap = off - pos_;
            if (opened_) {
                uint64_t t = data_start_ + ents_[idx_].off + ents_[idx_].size;
                if (pos_ + gap > t) return fail("пропуск выходит за границу файла NSP");
                if (!h_->pfs_gap(gap)) return fail("ошибка установки");
            } else if (idx_ < ents_.size() && pos_ + gap > data_start_ + ents_[idx_].off) {
                return fail("пропуск перескакивает файл NSP");
            }
            pos_ += gap;
        }
        return write(p, n);
    }

    bool finish() {
        if (!err_.empty()) return false;
        if (phase_ < 2) return fail("NSP обрезан (заголовок)");
        if (!stream(nullptr, 0)) return false;
        if (idx_ < ents_.size()) return fail("NSP обрезан (не хватает данных)");
        return true;
    }

private:
    struct Ent { uint64_t off, size; std::string name; };
    PfsHandler* h_;
    std::string err_;
    int phase_ = 0;
    std::vector<uint8_t> head_;
    uint32_t count_ = 0, strsz_ = 0;
    std::vector<Ent> ents_;
    uint64_t pos_ = 0, data_start_ = 0;
    size_t idx_ = 0;
    bool opened_ = false;

    size_t need() const { return phase_ == 0 ? 0x10 : (size_t)(0x10 + 0x18ull * count_ + strsz_); }
    bool fail(const std::string& e) { if (err_.empty()) err_ = e; return false; }
    static uint32_t r32(const uint8_t* p) { uint32_t v; memcpy(&v, p, 4); return v; }
    static uint64_t r64(const uint8_t* p) { uint64_t v; memcpy(&v, p, 8); return v; }

    bool parse_header() {
        if (memcmp(head_.data(), "PFS0", 4)) return fail("это не NSP (нет PFS0)");
        count_ = r32(head_.data() + 4); strsz_ = r32(head_.data() + 8);
        if (count_ == 0 || count_ > 4096 || strsz_ > (1u << 20)) return fail("повреждённый заголовок NSP");
        return true;
    }
    bool parse_entries() {
        const uint8_t* b = head_.data();
        const uint8_t* st = b + 0x10 + 0x18ull * count_;
        for (uint32_t i = 0; i < count_; i++) {
            const uint8_t* e = b + 0x10 + 0x18ull * i;
            Ent en; en.off = r64(e); en.size = r64(e + 8);
            uint32_t so = r32(e + 16);
            if (so >= strsz_) return fail("повреждённая таблица имён NSP");
            size_t len = strnlen((const char*)st + so, strsz_ - so);
            en.name.assign((const char*)st + so, len);
            ents_.push_back(en);
        }
        std::stable_sort(ents_.begin(), ents_.end(), [](const Ent& a, const Ent& c) { return a.off < c.off; });
        uint64_t last = 0;
        for (auto& e : ents_) {
            if (e.off < last) return fail("пересекающиеся файлы в NSP");
            last = e.off + e.size;
        }
        data_start_ = head_.size();
        return true;
    }
    bool stream(const uint8_t* p, size_t n) {
        for (;;) {
            if (idx_ >= ents_.size()) { pos_ += n; return true; }     // хвостовой мусор игнорируем
            Ent& e = ents_[idx_];
            uint64_t s = data_start_ + e.off, t = s + e.size;
            if (!opened_) {
                if (pos_ < s) {
                    if (!n) return true;
                    size_t k = (size_t)std::min<uint64_t>(n, s - pos_);
                    p += k; n -= k; pos_ += k;
                    continue;
                }
                if (!h_->pfs_begin(e.name, e.size, e.off + data_start_)) return fail("ошибка установки");
                opened_ = true;
            }
            if (e.size == 0 || pos_ >= t) {      // файл закончился (в т. ч. после пропуска)
                if (!h_->pfs_end()) return fail("ошибка установки");
                opened_ = false; idx_++;
                continue;
            }
            if (!n) return true;
            size_t k = (size_t)std::min<uint64_t>(n, t - pos_);
            if (!h_->pfs_data(p, k)) return fail("ошибка установки");
            p += k; n -= k; pos_ += k;
        }
    }
};
