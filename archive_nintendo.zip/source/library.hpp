#pragma once
#include <stdint.h>
#include <string>
#include <vector>

// Список скачанного/установленного: sdmc:/archive_nintendo/library.txt (TSV)
struct LibEntry {
    std::string hash;        // info_hash (hex)
    std::string name;
    uint64_t total = 0;
    uint32_t files_done = 0, files_total = 0;
    int status = 0;          // 0 приостановлено, 1 готово, 2 ошибка, 3 шла загрузка (прервано выходом/сбоем)
    int64_t when = 0;
    std::string note;
    std::string tpath;       // путь к .torrent (для продолжения)
    uint64_t cur_off = 0;    // сколько байт текущего (files_done) обычного файла уже записано
    std::string inst;        // состояние установки NSP для продолжения
    int mode = 0;            // 0 — автоустановка, 1 — просто положить в папку
};

struct Library {
    std::vector<LibEntry> items;
    std::string path;
    bool load(const std::string& p);
    bool save();
    LibEntry* find(const std::string& hash);
    void upsert(const LibEntry& e);
    void remove(const std::string& hash);
};
