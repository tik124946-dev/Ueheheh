#pragma once
// Заглушка системных сервисов: «хранилище» переживает пересоздание установщика (как ncm между запусками).
#include "../source/nsp_install.hpp"
#include "../source/util.hpp"
#include <map>
#include <string.h>

struct MockStore {
    std::map<std::string, std::vector<uint8_t>> reg, phs;
    std::vector<uint8_t> cnmt, rec;
    int tik = 0, commits = 0, pushes = 0, counter = 0;
    uint64_t rec_app = 0, meta_id = 0;
    bool preexisting = false;
};

inline void mp32(std::vector<uint8_t>& v, uint32_t x) { for (int i = 0; i < 4; i++) v.push_back(x >> (8 * i)); }
inline void mp64(std::vector<uint8_t>& v, uint64_t x) { for (int i = 0; i < 8; i++) v.push_back(x >> (8 * i)); }

inline std::vector<uint8_t> make_cnmt(uint64_t tid, uint8_t type, const std::vector<std::string>& cids) {
    std::vector<uint8_t> c; mp64(c, tid); mp32(c, 0x10000); c.push_back(type); c.push_back(0);
    c.push_back(0x10); c.push_back(0);
    c.push_back((uint8_t)cids.size()); c.push_back(0); c.push_back(0); c.push_back(0);
    c.push_back(0); c.insert(c.end(), 3, 0); mp32(c, 0); mp32(c, 0);
    mp64(c, 0xAAAAAAAAAAAAAAAAull); mp32(c, 0x5000); mp32(c, 0);
    for (auto& s : cids) {
        c.insert(c.end(), 32, 0x11);
        uint8_t id[16]; from_hex(s, id, 16); c.insert(c.end(), id, id + 16);
        mp32(c, 1234); c.push_back(0); c.push_back(0); c.push_back(1); c.push_back(0);
    }
    c.insert(c.end(), 32, 0x22);
    return c;
}

struct MockBackend : NspBackend {
    MockStore* s; std::string cur;
    explicit MockBackend(MockStore* st) : s(st) {}
    bool open(bool cleanup, std::string&) override { if (cleanup) s->phs.clear(); return true; }
    int begin_content(const uint8_t cid[16], uint64_t size, std::string&) override {
        std::string h = to_hex(cid, 16);
        if (s->reg.count(h) || (s->preexisting && h[0] == '1')) return 1;
        char b[40]; snprintf(b, sizeof b, "%032x", ++s->counter);
        cur = b; s->phs[cur].assign(size, 0); return 0;
    }
    int resume_content(const uint8_t cid[16], const std::string& ph, std::string& e) override {
        if (s->reg.count(to_hex(cid, 16))) return 1;
        if (!s->phs.count(ph)) { e = "нет placeholder"; return -1; }
        cur = ph; return 0;
    }
    std::string placeholder_hex() override { return cur; }
    bool write_content(uint64_t off, const uint8_t* p, size_t n, std::string& e) override {
        auto it = s->phs.find(cur);
        if (it == s->phs.end() || off + n > it->second.size()) { e = "bad write"; return false; }
        memcpy(it->second.data() + off, p, n); return true;
    }
    bool end_content(const uint8_t cid[16], std::string&) override { s->reg[to_hex(cid, 16)] = s->phs[cur]; s->phs.erase(cur); return true; }
    void abort_content() override { s->phs.erase(cur); }
    void detach() override {}
    void delete_placeholder(const std::string& ph) override { s->phs.erase(ph); }
    void delete_content(const uint8_t cid[16]) override { s->reg.erase(to_hex(cid, 16)); }
    bool read_cnmt(const uint8_t*, std::vector<uint8_t>& out, std::string&) override { out = s->cnmt; return true; }
    bool import_ticket(const std::vector<uint8_t>& t, const std::vector<uint8_t>& c, std::string&) override { if (!t.empty() && !c.empty()) s->tik++; return true; }
    bool set_meta(uint64_t id, uint32_t, uint8_t, const std::vector<uint8_t>& r, std::string&) override { s->meta_id = id; s->rec = r; return true; }
    bool commit_meta(std::string&) override { s->commits++; return true; }
    bool push_record(uint64_t app, uint64_t, uint32_t, uint8_t, std::string&) override { s->rec_app = app; s->pushes++; return true; }
};
