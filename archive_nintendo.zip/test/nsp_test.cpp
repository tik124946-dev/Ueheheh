// Тест логики установщика NSP на заглушке бэкенда: ./nsp_test
#include "../source/nsp_install.hpp"
#include "../source/util.hpp"
#include "mock_backend.hpp"
#include <stdio.h>
#include <stdlib.h>

#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)
static int fails = 0;

static void p32(std::vector<uint8_t>& v, uint32_t x) { for (int i = 0; i < 4; i++) v.push_back(x >> (8 * i)); }
static void p64(std::vector<uint8_t>& v, uint64_t x) { for (int i = 0; i < 8; i++) v.push_back(x >> (8 * i)); }
static std::vector<uint8_t> rnd(size_t n) { std::vector<uint8_t> v(n); for (auto& b : v) b = rand(); return v; }

static std::vector<uint8_t> make_nsp(const std::vector<std::pair<std::string, std::vector<uint8_t>>>& files) {
    std::string strtab; std::vector<uint32_t> so;
    for (auto& f : files) { so.push_back((uint32_t)strtab.size()); strtab += f.first; strtab.push_back(0); }
    while (strtab.size() % 16) strtab.push_back(0);
    std::vector<uint8_t> h; h.insert(h.end(), {'P', 'F', 'S', '0'});
    p32(h, (uint32_t)files.size()); p32(h, (uint32_t)strtab.size()); p32(h, 0);
    uint64_t off = 0;
    for (size_t i = 0; i < files.size(); i++) { p64(h, off); p64(h, files[i].second.size()); p32(h, so[i]); p32(h, 0); off += files[i].second.size(); }
    h.insert(h.end(), strtab.begin(), strtab.end());
    for (auto& f : files) h.insert(h.end(), f.second.begin(), f.second.end());
    return h;
}

int main() {
    srand(5);
    std::string c1 = "1111111111111111aaaaaaaaaaaaaaaa", c2 = "2222222222222222bbbbbbbbbbbbbbbb", cm = "33333333333333330123456789abcdef";
    auto n1 = rnd(300000), n2 = rnd(70000), nm = rnd(2048);
    uint64_t tid = 0x0100AAAABBBB0000ull;
    auto nsp = make_nsp({{c1 + ".nca", n1}, {c2 + ".nca", n2}, {cm + ".cnmt.nca", nm}, {"0100aaaa0000.tik", rnd(0x2C0)}, {"0100aaaa0000.cert", rnd(0x700)}, {"readme.txt", rnd(10)}});
    // 1) обычная установка, случайные размеры порций
    {
        MockStore st; st.cnmt = make_cnmt(tid, 0x80, {c1, c2});
        NspInstaller ins(new MockBackend(&st), "");
        size_t pos = 0;
        while (pos < nsp.size()) { size_t k = 1 + rand() % 9000; if (pos + k > nsp.size()) k = nsp.size() - pos; CHECK(ins.write(pos, nsp.data() + pos, k)); pos += k; }
        CHECK(ins.finish());
        CHECK(st.reg.size() == 3);
        CHECK(st.reg[c1] == n1 && st.reg[c2] == n2 && st.reg[cm] == nm);
        CHECK(st.tik == 1 && st.commits == 1 && st.pushes == 1);
        CHECK(st.rec_app == tid && st.meta_id == tid);
        CHECK(st.rec.size() == 8 + 0x10 + 3 * 0x18);
        CHECK(st.rec[2] == 3);
        CHECK(memcmp(st.rec.data() + 8 + 0x10, "\x33\x33\x33\x33\x33\x33\x33\x33\x01\x23\x45\x67\x89\xab\xcd\xef", 16) == 0);
        CHECK(st.rec[8 + 0x10 + 20] == 0 && st.rec[8 + 0x10 + 22] == 0);
        printf("info=%s\n", ins.info().c_str());
    }
    // 2) в NSP не хватает NCA
    {
        MockStore st; st.cnmt = make_cnmt(tid, 0x80, {c1, c2, "99999999999999999999999999999999"});
        NspInstaller ins(new MockBackend(&st), "");
        CHECK(ins.write(0, nsp.data(), nsp.size()));
        CHECK(!ins.finish());
        printf("ожидаемая ошибка: %s\n", ins.error().c_str());
        ins.abort();
        CHECK(st.reg.empty());                        // откат всё удалил
    }
    // 3) обрезанный NSP
    {
        MockStore st; st.cnmt = make_cnmt(tid, 0x80, {c1, c2});
        NspInstaller ins(new MockBackend(&st), "");
        CHECK(ins.write(0, nsp.data(), nsp.size() - 3000));
        CHECK(!ins.finish());
        printf("ожидаемая ошибка: %s\n", ins.error().c_str());
    }
    // 4) контент уже установлен — данные пропускаем
    {
        MockStore st; st.preexisting = true; st.cnmt = make_cnmt(tid, 0x80, {c1, c2});
        NspInstaller ins(new MockBackend(&st), "");
        CHECK(ins.write(0, nsp.data(), nsp.size()));
        CHECK(ins.finish());
        CHECK(st.reg.count(c1) == 0 && st.reg.count(c2) == 1);
    }
    // 5) системный тип и мусор вместо NSP
    {
        MockStore st; st.cnmt = make_cnmt(tid, 0x01, {c1, c2});
        NspInstaller ins(new MockBackend(&st), "");
        CHECK(ins.write(0, nsp.data(), nsp.size())); CHECK(!ins.finish());
        printf("ожидаемая ошибка: %s\n", ins.error().c_str());
        MockStore st2; NspInstaller ins2(new MockBackend(&st2), "");
        uint8_t junk[64] = {1, 2, 3}; CHECK(!ins2.write(0, junk, sizeof junk));
        printf("ожидаемая ошибка: %s\n", ins2.error().c_str());
    }
    // 6) патч/DLC: app id берётся из расширенного заголовка
    {
        MockStore st; st.cnmt = make_cnmt(tid + 0x800, 0x81, {c1, c2});
        NspInstaller ins(new MockBackend(&st), "");
        CHECK(ins.write(0, nsp.data(), nsp.size())); CHECK(ins.finish());
        CHECK(st.rec_app == 0xAAAAAAAAAAAAAAAAull);
    }
    // 7) прерывание посреди NCA → продолжение другим экземпляром: записанное не качаем заново
    {
        MockStore st; st.cnmt = make_cnmt(tid, 0x80, {c1, c2});
        std::string state; uint64_t cut = 0;
        {
            NspInstaller ins(new MockBackend(&st), "");
            // режем в середине второго NCA
            size_t hdr = nsp.size() - (n1.size() + n2.size() + nm.size() + 0x2C0 + 0x700 + 10);
            cut = hdr + n1.size() + n2.size() / 2;
            CHECK(ins.write(0, nsp.data(), cut));
            state = ins.suspend();
            printf("состояние: %s\\n", state.c_str());
            CHECK(!state.empty());
            CHECK(st.reg.count(c1) == 1 && st.reg.count(c2) == 0 && st.phs.size() == 1);
        }
        CHECK(st.phs.size() == 1);                    // placeholder пережил «перезапуск»
        {
            NspInstaller ins(new MockBackend(&st), state);
            // продолжение: сначала приходит заголовок (с нуля), потом приёмник просит прыгнуть
            size_t hdr = nsp.size() - (n1.size() + n2.size() + nm.size() + 0x2C0 + 0x700 + 10);
            CHECK(ins.write(0, nsp.data(), hdr));      // заголовок
            uint64_t so = 0;
            // первый NCA уже установлен → просьба пропустить до его конца
            CHECK(ins.write(hdr, nsp.data() + hdr, 1));
            CHECK(ins.take_seek(so));
            CHECK(so == hdr + n1.size());
            // «сеть» перепрыгнула: дальше данные идут с so
            CHECK(ins.write(so, nsp.data() + so, 10));
            CHECK(ins.take_seek(so));                  // второй NCA — продолжить с середины
            CHECK(so == hdr + n1.size() + n2.size() / 2);
            CHECK(ins.write(so, nsp.data() + so, nsp.size() - so));
            CHECK(ins.finish());
            CHECK(st.reg[c1] == n1 && st.reg[c2] == n2 && st.reg[cm] == nm);
            CHECK(st.phs.empty());
            CHECK(st.pushes == 1);
        }
    }
    // 8) отмена: состояние + discard убирает всё
    {
        MockStore st; st.cnmt = make_cnmt(tid, 0x80, {c1, c2});
        std::string state;
        {
            NspInstaller ins(new MockBackend(&st), "");
            size_t hdr = nsp.size() - (n1.size() + n2.size() + nm.size() + 0x2C0 + 0x700 + 10);
            CHECK(ins.write(0, nsp.data(), hdr + n1.size() + 1000));
            state = ins.suspend();
        }
        CHECK(st.reg.size() == 1 && st.phs.size() == 1);
        MockBackend* be = new MockBackend(&st);
        nsp_discard(be, state);
        delete be;
        CHECK(st.reg.empty() && st.phs.empty());
    }
    printf(fails ? "НЕУДАЧА (%d)\n" : "ВСЕ ТЕСТЫ NSP ПРОШЛИ\n", fails);
    return fails != 0;
}
