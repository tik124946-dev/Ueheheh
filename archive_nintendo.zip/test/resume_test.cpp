// Сквозной тест докачки: ./resume_test <dir с torrents/ и payload/> <рабочая папка>
#include "../source/swarm.hpp"
#include "../source/router.hpp"
#include "../source/util.hpp"
#include "mock_backend.hpp"
#include <stdio.h>
#include <stdlib.h>

#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)
static int fails = 0;

struct TestPlatform : Platform {
    std::string r; MockStore* st; int nsess = 0;
    TestPlatform(const std::string& root, MockStore* s) : r(root), st(s) {}
    std::string root() override { return r; }
    std::string time_str() override { return "00:00"; }
    int64_t epoch() override { return 0; }
    std::string date_str(int64_t) override { return ""; }
    int64_t free_space(int) override { return 1ll << 40; }
    int64_t total_space(int) override { return 1ll << 40; }
    bool can_install() override { return true; }
    Installer* new_installer(int, const std::string& resume) override { return new NspInstaller(new MockBackend(st), resume); }
    void discard_install(int, const std::string& s) override { MockBackend* b = new MockBackend(st); nsp_discard(b, s); delete b; }
    void keep_awake(bool) override {}
    void backlight(bool) override {}
};

static bool run_until(Swarm& sw, uint64_t target_consumed, uint64_t timeout_ms = 40000) {
    uint64_t t0 = now_ms();
    while (!sw.finished() && !sw.failed() && sw.consumed_bytes() < target_consumed && now_ms() - t0 < timeout_ms) sw.tick(now_ms());
    return !sw.failed();
}

int main(int argc, char** argv) {
    if (argc < 3) return 2;
    std::string base = argv[1], work = argv[2];
    std::string payload = base + "/payload";
    // ───────── 1) NSP: прервали посреди → продолжили ─────────
    {
        Meta m; std::string e;
        CHECK(Meta::load(base + "/torrents/d_nsp.torrent", m, e));
        MockStore st;
        std::string c1 = "11111111111111111111111111111111", c2 = "22222222222222222222222222222222", c3 = "33333333333333333333333333333333", cm = "44444444444444444444444444444444";
        st.cnmt = make_cnmt(0x0100AAAABBBB0000ull, 0x80, {c1, c2, c3});
        TestPlatform pf(work + "/nsp/", &st);
        mkdirs(pf.root());
        std::string state; uint64_t pos1 = 0;
        {
            Router r(&pf, true, 0);
            Swarm sw(m, &r, 0, 1u << 20);
            CHECK(run_until(sw, m.total * 6 / 10));          // ~60%: внутри второго NCA
            pos1 = sw.consumed_bytes();
            r.flush(); state = r.inst_state(); r.suspend();
        }
        printf("сеанс 1: принято позиций %llu из %llu, состояние: %s\n", (unsigned long long)pos1, (unsigned long long)m.total, state.c_str());
        CHECK(!state.empty());
        CHECK(st.reg.count(c1) == 1);                         // первый NCA уже зарегистрирован
        {
            ResumeInfo ri; ri.idx = 0; ri.inst = state;
            Router r(&pf, true, 0, ri);
            Swarm sw(m, &r, m.files[0].off, 1u << 20);
            CHECK(run_until(sw, m.total + 1));
            CHECK(sw.finished());
            printf("сеанс 2: по сети принято %llu байт (всего NSP %llu)\n", (unsigned long long)sw.received_bytes(), (unsigned long long)m.total);
            CHECK(sw.received_bytes() < m.total * 6 / 10);    // сильно меньше полного размера: уже установленное не качалось
            CHECK(r.n_installed() == 1);
        }
        CHECK(st.reg.size() == 4 && st.phs.empty() && st.pushes == 1);
        // содержимое NCA совпадает с исходным NSP
        std::vector<uint8_t> nsp; read_file(payload + "/game.nsp", nsp, 64u << 20);
        auto find = [&](const std::string& name) -> std::vector<uint8_t> {
            std::string s((const char*)nsp.data(), nsp.size());
            // имя NCA в таблице строк → данные идут подряд; ищем по sha-независимому признаку: размер/порядок
            (void)name; return {};
        };
        (void)find;
        // проверяем размеры
        CHECK(st.reg[c1].size() == 1300000 && st.reg[c2].size() == 2200000 && st.reg[c3].size() == 500000 && st.reg[cm].size() == 16384);
        // сравниваем с исходниками из NSP (данные NCA идут подряд после заголовка)
        size_t hdr = nsp.size() - (1300000 + 2200000 + 500000 + 16384 + 0x2C0 + 0x700 + 4);
        CHECK(memcmp(st.reg[c1].data(), nsp.data() + hdr, 1300000) == 0);
        CHECK(memcmp(st.reg[c2].data(), nsp.data() + hdr + 1300000, 2200000) == 0);
        CHECK(memcmp(st.reg[c3].data(), nsp.data() + hdr + 3500000, 500000) == 0);
        CHECK(st.tik == 1);
    }
    // ───────── 2) обычные файлы: докачка с середины файла ─────────
    {
        Meta m; std::string e;
        CHECK(Meta::load(base + "/torrents/a_mocktest.torrent", m, e));
        MockStore st;
        TestPlatform pf(work + "/plain/", &st);
        mkdirs(pf.root());
        uint64_t off = 0, total1 = 0;
        {
            Router r(&pf, false, 0);
            Swarm sw(m, &r, 0, 1u << 20);
            CHECK(run_until(sw, 1500000));                    // посреди первого файла (3.3 МБ)
            total1 = sw.consumed_bytes();
            r.flush(); off = r.file_pos(); r.suspend();
        }
        printf("сеанс 1: записано %llu байт файла\n", (unsigned long long)off);
        CHECK(off > 0 && off < m.files[0].len);
        {
            ResumeInfo ri; ri.idx = 0; ri.off = off;
            Router r(&pf, false, 0, ri);
            Swarm sw(m, &r, m.files[0].off + off, 1u << 20);
            CHECK(run_until(sw, m.total + 1));
            CHECK(sw.finished());
            printf("сеанс 2: по сети принято %llu из %llu\n", (unsigned long long)sw.received_bytes(), (unsigned long long)m.total);
            CHECK(sw.received_bytes() < m.total - off + 2 * m.plen);
        }
        (void)total1;
        // сравнение с исходниками
        std::string cmd = "diff -r " + payload + "/mocktest " + pf.root() + "archive_nintendo/downloads/mocktest > /dev/null";
        CHECK(system(cmd.c_str()) == 0);
    }
    // ───────── 3) отмена: хвосты NSP удаляются ─────────
    {
        Meta m; std::string e;
        CHECK(Meta::load(base + "/torrents/d_nsp.torrent", m, e));
        MockStore st; st.cnmt = make_cnmt(0x0100AAAABBBB0000ull, 0x80, {"11111111111111111111111111111111"});
        TestPlatform pf(work + "/cancel/", &st);
        mkdirs(pf.root());
        std::string state;
        {
            Router r(&pf, true, 0);
            Swarm sw(m, &r, 0, 1u << 20);
            CHECK(run_until(sw, m.total / 2));
            r.flush(); state = r.inst_state(); r.suspend();
        }
        CHECK(!st.reg.empty() || !st.phs.empty());
        pf.discard_install(0, state);
        CHECK(st.reg.empty() && st.phs.empty());
    }
    // ───────── 4) режим «в папку»: NSP кладётся файлом, ничего не устанавливается ─────────
    {
        Meta m; std::string e;
        CHECK(Meta::load(base + "/torrents/d_nsp.torrent", m, e));
        MockStore st; st.cnmt = make_cnmt(0x0100AAAABBBB0000ull, 0x80, {"11111111111111111111111111111111"});
        TestPlatform pf(work + "/raw/", &st);
        mkdirs(pf.root());
        Router r(&pf, true, 0, ResumeInfo(), true);
        Swarm sw(m, &r, 0, 1u << 20);
        CHECK(run_until(sw, m.total + 1));
        CHECK(sw.finished());
        CHECK(st.reg.empty() && st.phs.empty() && st.pushes == 0 && st.tik == 0);
        std::string want = pf.root() + "archive_nintendo/downloads/game.nsp";
        CHECK(plain_dest(&pf, m, 0, true) == want);
        std::string cmd = "cmp " + payload + "/game.nsp " + want;
        CHECK(system(cmd.c_str()) == 0);
        printf("в папку: %s\n", r.summary().c_str());
    }
    // режим «в папку»: многофайловый торрент ложится в downloads/<название>/…, докачка с середины файла
    {
        Meta m; std::string e;
        CHECK(Meta::load(base + "/torrents/a_mocktest.torrent", m, e));
        MockStore st;
        TestPlatform pf(work + "/raw2/", &st);
        mkdirs(pf.root());
        uint64_t off = 0;
        {
            Router r(&pf, true, 0, ResumeInfo(), true);
            Swarm sw(m, &r, 0, 1u << 20);
            CHECK(run_until(sw, 1200000));
            r.flush(); off = r.file_pos(); r.suspend();
        }
        CHECK(off > 0 && off < m.files[0].len);
        {
            ResumeInfo ri; ri.idx = 0; ri.off = off;
            Router r(&pf, true, 0, ri, true);
            Swarm sw(m, &r, m.files[0].off + off, 1u << 20);
            CHECK(run_until(sw, m.total + 1));
            CHECK(sw.finished());
        }
        std::string cmd = "diff -r " + payload + "/mocktest " + pf.root() + "archive_nintendo/downloads/mocktest > /dev/null";
        CHECK(system(cmd.c_str()) == 0);
    }
    printf(fails ? "ДОКАЧКА: НЕУДАЧА (%d)\n" : "ДОКАЧКА: ВСЁ ОК\n", fails);
    return fails != 0;
}
