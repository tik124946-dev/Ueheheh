#pragma once
#include "../source/platform.hpp"
#include <time.h>
#include <stdio.h>

struct HostPlatform : Platform {
    std::string r;
    bool backlight_on = true; int bl_changes = 0; bool awake = false;
    int64_t free_b = 80ll << 30, total_b = 256ll << 30;
    explicit HostPlatform(const std::string& root) : r(root) {}
    std::string root() override { return r; }
    std::string time_str() override { return "14:05"; }
    int64_t epoch() override { return (int64_t)time(nullptr); }
    std::string date_str(int64_t e) override { time_t t = (time_t)e; struct tm tm; localtime_r(&t, &tm); char b[32]; strftime(b, sizeof b, "%d.%m.%y", &tm); return b; }
    int64_t free_space(int s) override { return s == 0 ? free_b : 20ll << 30; }
    int64_t total_space(int s) override { return s == 0 ? total_b : 24ll << 30; }
    bool can_install() override { return false; }
    Installer* new_installer(int, const std::string&) override { return nullptr; }
    void discard_install(int, const std::string&) override {}
    void keep_awake(bool on) override { awake = on; }
    void backlight(bool on) override { backlight_on = on; bl_changes++; }
};
